import React from 'react'

function Cards({ setLink, link, item }) {
    return (
        <div className='cards'>
            <div className="card_img">
                <img src={item.image} alt="" />
            </div>
            <div className="card_about">
                <div className="title">
                    <h2>{item.name}</h2> <p>{item.price} $</p>
                </div>
                <div className="text">
                    <p>{item.info}</p>
                    <button onClick={() => {
                        const filterTrash = link.filter((el) => {
                            return el.id != item.id
                        })
                        setLink(filterTrash)
                    }}>No Interested</button>
                </div>
            </div>
        </div>
    )
}

export default Cards